<html>
<!-- en-tete technique-->
<head>
<title>DAB</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="description" content="Exemple de formulaire">
<meta name="keywords" lang="fr" content="html,formulaire,boutons">
<meta name="Author" content="Grégoire Maréchal">
<!-- appel de la feuille de style externe -->
 <link href="style_formulaire.css" type="text/css" rel="stylesheet" media="all">
</head>
<body>
<h4>Contrôle du code secret</h4>



<?php
/* récupération des données postées dans le formulaire */
$codesecret=$_POST["codesecret"];

if( )
{
	
}
else // ceci est le cas où...
{
	
}
echo "<p>Vous êtes sûr(e) qu'il marche ce programme ?</p>"
?>


</body>
</html>